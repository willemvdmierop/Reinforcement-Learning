from setuptools import setup

setup(name='custom_env',
    version='0.1',
    install_requires=['gym','numpy']
    )
